/**
 * @module xide/Keyboard
 **/
define([
    'dojo/_base/declare',
    'dojo/_base/lang',
    "dojo/has",
    'xide/types',
    'xide/utils'
], function (declare, lang, has, types,utils) {

    "use strict";

    /**
     * First things first, mixin KEYBOARD_FLAGS into core types.
     */
    lang.mixin(types, {

        /**
         * KEYBOARD_EVENT describes all possible events a subscriber can listen to.
         *
         * @enum module:xide/types/KEYBOARD_EVENT
         * @memberOf module:xide/types
         */
        KEYBOARD_EVENT: {

            /**
             * Add a custom callback for a key-up event.
             *
             * @default null, not required.
             * @type {function}
             * @constant
             */
            UP: 'on_keyup',
            /**
             * Add a custom callback for a key-dow event.
             *
             * @default null, not required.
             * @type {function}
             * @constant
             */
            DOWN: 'on_keydown',
            /**
             * Add a custom callback for a release event. This is similar to keyup, but will fire once
             * when ALL of the keys of a combo have been released. If you're unsure, you probably want to
             * ignore this and use UP.
             *
             * @default null, not required.
             * @type {function}
             * @constant
             */
            RELEASE: 'on_release'
        }
    });

    /**
     * Define a public struct for a 'keyboard - mapping
     */
    lang.mixin(types, {

        /**
         * KEYBOARD_MAPPING
         *
         * Keys accepted in human readable format as 'shift s', see the full map:
         *
         _modifier_event_mapping =
         "cmd"   : "metaKey"
         "ctrl"  : "ctrlKey"
         "shift" : "shiftKey"
         "alt"   : "altKey"

         _keycode_alternate_names =
         "escape"        : "esc"
         "control"       : "ctrl"
         "command"       : "cmd"
         "break"         : "pause"
         "windows"       : "cmd"
         "option"        : "alt"
         "caps_lock"     : "caps"
         "apostrophe"    : "\'"
         "semicolon"     : ";"
         "tilde"         : "~"
         "accent"        : "`"
         "scroll_lock"   : "scroll"
          "num_lock"      : "num"

         _keycode_shifted_keys =
         "/"     : "?"
         "."     : ">"
         ","     : "<"
         "\'"    : "\""
         ";"     : ":"
         "["     : "{"
     "]"     : "}"
         "\\"    : "|"
         "`"     : "~"
         "="     : "+"
         "-"     : "_"
         "1"     : "!"
         "2"     : "@"
         "3"     : "#"
         "4"     : "$"
         "5"     : "%"
         "6"     : "^"
         "7"     : "&"
         "8"     : "*"
         "9"     : "("
         "0"     : ")"

         _keycode_dictionary =
         0   : "\\"          # Firefox reports this keyCode when shift is held
         8   : "backspace"
         9   : "tab"
         12  : "num"
         13  : "enter"
         16  : "shift"
         17  : "ctrl"
         18  : "alt"
         19  : "pause"
         20  : "caps"
         27  : "esc"
         32  : "space"
         33  : "pageup"
         34  : "pagedown"
         35  : "end"
         36  : "home"
         37  : "left"
         38  : "up"
         39  : "right"
         40  : "down"
         44  : "print"
         45  : "insert"
         46  : "delete"
         48  : "0"
         49  : "1"
         50  : "2"
         51  : "3"
         52  : "4"
         53  : "5"
         54  : "6"
         55  : "7"
         56  : "8"
         57  : "9"
         65  : "a"
         66  : "b"
         67  : "c"
         68  : "d"
         69  : "e"
         70  : "f"
         71  : "g"
         72  : "h"
         73  : "i"
         74  : "j"
         75  : "k"
         76  : "l"
         77  : "m"
         78  : "n"
         79  : "o"
         80  : "p"
         81  : "q"
         82  : "r"
         83  : "s"
         84  : "t"
         85  : "u"
         86  : "v"
         87  : "w"
         88  : "x"
         89  : "y"
         90  : "z"
         91  : "cmd"
         92  : "cmd"
         93  : "cmd"
         96  : "num_0"
         97  : "num_1"
         98  : "num_2"
         99  : "num_3"
         100 : "num_4"
         101 : "num_5"
         102 : "num_6"
         103 : "num_7"
         104 : "num_8"
         105 : "num_9"
         106 : "num_multiply"
         107 : "num_add"
         108 : "num_enter"
         109 : "num_subtract"
         110 : "num_decimal"
         111 : "num_divide"
         112 : "f1"
         113 : "f2"
         114 : "f3"
         115 : "f4"
         116 : "f5"
         117 : "f6"
         118 : "f7"
         119 : "f8"
         120 : "f9"
         121 : "f10"
         122 : "f11"
         123 : "f12"
         124 : "print"
         144 : "num"
         145 : "scroll"
         186 : ";"
         187 : "="
         188 : ","
         189 : "-"
         190 : "."
         191 : "/"
         192 : "`"
         219 : "["
         220 : "\\"
         221 : "]"
         222 : "\'"
         223 : "`"
         224 : "cmd"
         225 : "alt"
         # Opera weirdness
         57392   : "ctrl"
         63289   : "num"
         # Firefox weirdness
         59 : ";"
         61 : "-"
         173 : "="

         *
         * @class module:xide/types/KEYBOARD_MAPPING
         * @memberOf module:xide/types
         */

        /**
         * KEYBOARD_MAPPING is defines keyboard mapping struct:
         *
         * @memberOf module:xide/types
         * @class module:xide/types/KEYBOARD_EVENT
         *
         */
        KEYBOARD_MAPPING:{
            /**
             * @param keys {string|string[]} the key sequence (see below for the right codes ).
             * This option can be either an array of strings, or a single space separated string of key names that describe
             * the keys that make up the combo.
             */
            keys:null,
            /**
             * @param handler {function|xide/types/KEYBOARD_EVENT} the callback for the key sequence. This can be one
             * function an structure per keyboard event. Usually its enough to leave this empty. You can also pass this
             * in the params
             */
            handler:null,
            /**
             * @param scope {Object|null} the scope in which the handler(s) are excecuted.
             */
            scope:null,
            /**
             * @param target {HTMLElement|null} the element on the listerner is bound to. Null means global!
             */
            target:null,
            /**
             * @param type {string|null} the keypress combo type, can be:
             * simple_combo(keys, on_keydown_callback); // Registers a very basic combo;
             * counting_combo(keys, on_count_callback); // Registers a counting combo
             * sequence_combo(keys, callback); // Registers a sequence combo
             * register_combo(combo_dictionary); // Registers a combo from a dictionary
             */
            type:null,
            /**
             * @param mixin to override the 'keypress' libraries internal setup for a listener
             * @default {

                prevent_repeat: false,
                prevent_default: false,
                is_unordered: false,
                is_counting: false,
                is_exclusive: false,
                is_solitary: false,
                is_sequence: false
            */
            params:null,
            /**
             *
             * @param mouse {Object|null|true|false} filter to setup an addtional trigger constraint for keyboard
             * sequence. Example: mouse.before='mousedown' and keys ='ctrl' will fire the handler when the mouse is hold whilst
             * ctrl key is hold. default:null.
             *
             */
            mouse:{
                brefore:null,//true
                after:null//false
            },
            eventArgs:null
        }

    });

    /**
     * Global array of keypress listeners
     * @type {Array}
     * @private
     */
    var listeners = [],
        byNode = {};

    /**
     * Util to extend a keyboard mapping with control functions per listener. Keyboard mappings can
     * have multiple key sequences and this will take care about stop(), listen() and destroy().
     * @param mapping
     * @param listeners
     */
    var addListenerControls = function(mapping,listeners){

        mapping.stop = function (){
            _.each(listeners,function(listener){
                listener.stop_listening();
            });
        }

        mapping.listen = function (){
            _.each(listeners,function(listener) {
                listener.listen();
            });
        }

        mapping.destroy = function (){
            mapping.stop();

            var _listeners = listeners;

            _.each(listeners,function(listener) {
                if(listener && listener.destroy) {
                    listener.destroy();
                    listeners.remove(listener);
                }else{
                    console.error('kb destroy failed');
                }
            });
        }

        return mapping;
    };

    /**
     * Safe link to keypress prototype
     * @type {Listener|keypress.Listener}
     * @private
     */
    var keypressProto = window ? window['keypress'] ? window.keypress.Listener : null : null;
    if(!keypressProto){
        console.error('you need keypress.min.js installed to use xide/Keyboard');
    }

    /**
     * Generic keyboard handler, using the external 'keypress' Javascript library
     * which handles keyboard events a bit more elegant and robust, it does allow
     * registration of keyboard - sequences as 'shift s':
     * @example
     *
     * listener.simple_combo("shift s", function() {
     *  console.log("You pressed shift and s");
     * });
     *
     * @link http://dmauro.github.io/Keypress/
     * @link https://github.com/dmauro/Keypress/blob/master/keypress.coffee#L728-864
     * @class module:xide/grid/Keyboard
     */
    var _Keyboard = declare("xide/grid/Keyboard", null, {

        /**
         * @member listener {Object[]} all keypress listener instances
         */
        listeners: listeners,
        /**
         * The default setup for a listener, this is 'keypress' specific.
         *
         * @returns {{prevent_repeat: boolean, prevent_default: boolean, is_unordered: boolean, is_counting: boolean, is_exclusive: boolean, is_solitary: boolean, is_sequence: boolean}}
         */
        keyPressDefault: function () {

            return {
                prevent_repeat: false,
                prevent_default: true,
                is_unordered: false,
                is_counting: false,
                is_exclusive: false,
                is_solitary: false,
                is_sequence: false
            }
        },

        /**
         * Private listener creation method, accepts multiple key sequences for the same handler.
         *
         * @param keys {string|string[]} the key sequence (see below for the right codes ).
         * This option can be either an array of strings, or a single space separated string of key names that describe
         * the keys that make up the combo.
         *
         * @param params {Object|null} an additional parameter structure to override the default 'keypress' setup.
         * See this.keyPressDefault
         *
         * @param scope {Object|null} the scope in which the handler(s) are excecuted, defaults to 'this' as we are
         * a mixin.
         *
         *
         * @param type {string|null} the keypress combo type, can be:
         * simple_combo(keys, on_keydown_callback); // Registers a very basic combo;
         * counting_combo(keys, on_count_callback); // Registers a counting combo
         * sequence_combo(keys, callback); // Registers a sequence combo
         * register_combo(combo_dictionary); // Registers a combo from a dictionary
         *
         * @param handler {function|xide/types/KEYBOARD_EVENT} the callback for the key sequence. This can be one
         * function an structure per keyboard event. Usually its enough to leave this empty. You can also pass this
         * in the params

         * @param target {HTMLElement|null} the element on the listerner is bound to. Null means global!
         *
         * @public
         */
        addKeyboardListerner: function (keys, params, type, scope, handler, target,eventArgs) {

            // prepare keypress args
            var _defaults = lang.clone(this.keyPressDefault());
            //mixin override
            if (params) {
                lang.mixin(_defaults, params);
            }

            // defaults
            _defaults['this'] = _defaults['this'] || scope || this;

            // use simple_combo as default
            type = type || 'simple_combo';

            //normalize to array
            keys = !lang.isArray(keys) ? [keys] : keys;

            var _keypress = window['keypress'];
            var _listeners = [];


            _.each(keys,function(key_seq){

                var listener = null,
                    targetId = target.id,
                    wasCached = !!byNode[target.id];


                listener =  byNode[targetId] || new keypressProto(target, _defaults) ;

                listener[type](key_seq, function (e) {
                    if (handler) {
                        handler.apply(_defaults['this'],eventArgs);
                    }
                });

                byNode[target.id] = listener;


                if(!wasCached) {
                    //store in global
                    this.listeners.push(listener);

                    //store in local
                    _listeners.push(listener);
                }

            },this);


            return _listeners;
        },
        /**
         * Public interface to register a keyboard mapping
         * @param mapping {xide/types/KEYBOARD_MAPPING}
         * @returns {xide/types/KEYBOARD_MAPPING}
         */
        registerKeyboardMapping:function(mapping){
            try {
                var listeners = this.addKeyboardListerner(mapping.keys, mapping.params, null, mapping.scope, mapping.handler, mapping.target, mapping.eventArgs);
                mapping.listeners = listeners;
                return addListenerControls(mapping, listeners);
            }catch(e){
                console.error('create keyboard mapping failed ',e);
            }
        }
    });


    /**
     * Static mapping factory
     * @param keys
     * @param params
     * @param type
     * @param scope
     * @param handler
     * @param target
     * @memberOf module:xide/Keyboard
     * @returns {xide/types/KEYBOARD_MAPPING}
     */
    _Keyboard.createMapping = function(keys, params, type, scope, handler, target,eventArgs){

        var mapping=lang.clone(types.KEYBOARD_MAPPING),//@TODO: bad copy, uses a ctr followed by a lang.mixin
            _gethandler = function(__handler){return lang.isString(__handler) ? lang.hitch(scope, __handler) : __handler};

        mapping.keys=keys;
        mapping.params=params||{};
        mapping.type=type;
        mapping.scope=scope;
        mapping.handler=_gethandler(handler);
        mapping.target=target;
        mapping.eventArgs=eventArgs;

        mapping.setHandler=function(event,handler){
            mapping.params[event]= _gethandler(handler);
            return mapping;
        }

        return mapping;

    };

    return _Keyboard;
});