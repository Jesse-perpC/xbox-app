# sampleprojectchild

This repositry is a sample project to test https://github.com/ibm-js/jsdoc-amddcl/.
