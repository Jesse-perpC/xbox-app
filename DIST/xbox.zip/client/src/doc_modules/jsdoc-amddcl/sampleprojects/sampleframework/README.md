# sampleframework

This repositry is a sample framework project to test https://github.com/ibm-js/jsdoc-amddcl/.
