//>>built
define("xapp/widgets/nls/fr/TemplatedWidgetBase",{});
//@ sourceMappingURL=TemplatedWidgetBase.js.map