//>>built
define("dojo/cldr/nls/tr/japanese",{"dateFormat-short":"d.MM.y G","dateFormat-medium":"d MMM y G","dateFormat-long":"d MMMM y G","dateFormat-full":"d MMMM y G EEEE"});
//@ sourceMappingURL=japanese.js.map