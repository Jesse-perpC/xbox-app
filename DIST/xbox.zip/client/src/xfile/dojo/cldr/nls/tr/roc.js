//>>built
define("dojo/cldr/nls/tr/roc",{eraAbbr:["Before R.O.C.","Minguo"]});
//@ sourceMappingURL=roc.js.map