//>>built
define("dojo/cldr/nls/pt-pt/number",{group:"\u00a0","decimalFormat-long":"000 bili\u00f5es",currencyFormat:"#,##0.00\u00a0\u00a4","decimalFormat-short":"000\u00a0Bi",decimal:","});
//@ sourceMappingURL=number.js.map