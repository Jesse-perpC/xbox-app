//>>built
define("dojo/cldr/nls/tr/coptic",{"months-format-wide":"T\u00fbt B\u00e2be Hatur Keyhek T\u00fbbe Im\u015fir Bermuhat Bermude Pey\u015ftes Bune Ebip M\u0131sr\u00ee Nes\u00ee".split(" ")});
//@ sourceMappingURL=coptic.js.map