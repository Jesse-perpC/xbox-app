//>>built
define("dojo/cldr/nls/tr/ethiopic",{"months-format-wide":"Meskerem Tikimt Hidar Tahsas Tir Yakatit Magabit Miyazya Ginbot Sene Hamle Nehasa Pagumiene".split(" ")});
//@ sourceMappingURL=ethiopic.js.map