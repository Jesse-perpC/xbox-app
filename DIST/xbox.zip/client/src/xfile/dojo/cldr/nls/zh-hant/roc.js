//>>built
define("dojo/cldr/nls/zh-hant/roc",{eraAbbr:["\u6c11\u570b\u524d","\u6c11\u570b"]});
//@ sourceMappingURL=roc.js.map