//>>built
define("dojo/cldr/nls/pt-pt/japanese",{"dateFormat-short":"d/M/y G"});
//@ sourceMappingURL=japanese.js.map