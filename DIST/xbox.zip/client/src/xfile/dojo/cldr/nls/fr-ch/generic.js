//>>built
define("dojo/cldr/nls/fr-ch/generic",{"dateFormat-full":"EEEE, d MMMM y G","dateFormat-short":"dd.MM.yy GGGGG"});
//@ sourceMappingURL=generic.js.map