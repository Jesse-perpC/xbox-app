//>>built
define("dojo/cldr/nls/sk/currency",{HKD_displayName:"Hongkongsk\u00fd dol\u00e1r",CHF_displayName:"\u0160vaj\u010diarsk\u00fd frank",JPY_symbol:"JPY",CAD_displayName:"Kanadsk\u00fd dol\u00e1r",HKD_symbol:"HKD",CNY_displayName:"\u010c\u00ednsky j\u00fcan",USD_symbol:"USD",AUD_displayName:"Austr\u00e1lsky dol\u00e1r",JPY_displayName:"Japonsk\u00fd jen",CAD_symbol:"CAD",USD_displayName:"Americk\u00fd dol\u00e1r",CNY_symbol:"CNY",GBP_displayName:"Britsk\u00e1 libra",GBP_symbol:"GBP",AUD_symbol:"AUD",
EUR_displayName:"Euro"});
//@ sourceMappingURL=currency.js.map