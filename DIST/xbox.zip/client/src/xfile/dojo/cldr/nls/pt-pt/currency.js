//>>built
define("dojo/cldr/nls/pt-pt/currency",{CAD_displayName:"D\u00f3lar canadiano",USD_displayName:"D\u00f3lar dos Estados Unidos"});
//@ sourceMappingURL=currency.js.map