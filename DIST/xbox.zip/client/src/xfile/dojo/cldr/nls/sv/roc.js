//>>built
define("dojo/cldr/nls/sv/roc",{eraAbbr:["f\u00f6re R.K.","R.K."]});
//@ sourceMappingURL=roc.js.map