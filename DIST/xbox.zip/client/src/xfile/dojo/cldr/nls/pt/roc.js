//>>built
define("dojo/cldr/nls/pt/roc",{eraAbbr:["Antes de R.O.C.","R.O.C."]});
//@ sourceMappingURL=roc.js.map