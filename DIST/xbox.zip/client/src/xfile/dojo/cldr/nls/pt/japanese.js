//>>built
define("dojo/cldr/nls/pt/japanese",{"dateFormat-short":"dd/MM/yy GGGGG","dateFormat-medium":"dd/MM/y G","dateFormat-long":"d 'de' MMMM 'de' y G","dateFormat-full":"EEEE, d 'de' MMMM 'de' y G"});
//@ sourceMappingURL=japanese.js.map