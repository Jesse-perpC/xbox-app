//>>built
define("dojo/cldr/nls/pt-pt/roc",{"dateFormat-short":"d/M/y G"});
//@ sourceMappingURL=roc.js.map