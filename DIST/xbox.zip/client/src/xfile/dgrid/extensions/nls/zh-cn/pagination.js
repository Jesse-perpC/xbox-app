define({
  	status: "${start} - ${end} 共 ${total} 条结果",
		gotoFirst: "首页",
		gotoNext: "后一页",
		gotoPrev: "前一页",
		gotoLast: "末页",
		gotoPage: "到这页",
		jumpPage: "跳到页"
});
