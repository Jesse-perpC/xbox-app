define({ root:
{
	"device":"Device:",
	"zoom":"Zoom:",
	"angle":"Angle:"
}
});
