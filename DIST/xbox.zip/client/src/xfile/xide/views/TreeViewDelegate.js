//>>built
define("xide/views/TreeViewDelegate",["dojo/_base/declare"],function(a){return a("xide.views.TreeViewDelegate",null,{currentTreeNode:null,onTreeClicked:function(a,b){this.currentTreeNode=b;this.currentTreeDataItem=a}})});
//# sourceMappingURL=TreeViewDelegate.js.map