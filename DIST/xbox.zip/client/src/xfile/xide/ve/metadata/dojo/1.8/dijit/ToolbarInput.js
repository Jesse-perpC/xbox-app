define([
	"dojo/_base/declare",
	"./layout/ContainerInput"
], function(
	declare,
	ContainerInput
) {

return declare(ContainerInput, {

	propertyName: "label",
	supportsHTML: true
	
});

});