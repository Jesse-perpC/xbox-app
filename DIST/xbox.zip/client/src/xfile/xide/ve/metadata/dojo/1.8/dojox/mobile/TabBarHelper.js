define([
	"dojo/_base/declare",
	"./_FixedElemMixin"
], function(
	declare,
	_FixedElemMixin
) {

return declare(_FixedElemMixin, {});

});