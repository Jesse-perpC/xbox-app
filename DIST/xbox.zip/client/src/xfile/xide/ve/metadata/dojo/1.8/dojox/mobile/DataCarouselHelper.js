define([
	"dojo/_base/declare",
	"../../dojo/data/DataStoreBasedWidgetHelper"
], function (
	declare,
	DataStoreBasedWidgetHelper
) {

return declare([DataStoreBasedWidgetHelper], {

	//Everything deferred to superclass

});

});
