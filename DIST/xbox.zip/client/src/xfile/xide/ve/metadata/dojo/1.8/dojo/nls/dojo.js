define({ root: {

		//data/ItemFileReadStoreInput.js
		"dataStoreDetails":"DataStore Details",
		"itemFileReadStore":"ItemFileReadStore",
		"itemFileWriteStore":"ItemFileWriteStore",
		"dataStoreId":"DataStore ID:",
		"url":"URL:",
		"scriptLabel":"Script:"

}});
