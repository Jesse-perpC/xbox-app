define([
	"dojo/_base/declare",
	"../../dojo/data/DataStoreBasedCreateTool",
], function (
	declare,
	DataStoreBasedCreateTool
) {

// NOTE: Used by EdgeToEdgeDataList, RoundRectDataList, Carousel

return declare(DataStoreBasedCreateTool, {

	//Defer to superclass
	
});

});