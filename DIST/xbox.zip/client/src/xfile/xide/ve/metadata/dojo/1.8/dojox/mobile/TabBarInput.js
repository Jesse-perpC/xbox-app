define([
	"dojo/_base/declare",
	"../../dijit/layout/ContainerInput"
], function(
	declare,
	ContainerInput
) {

return declare(ContainerInput, {

	propertyName: "label"
	
});

});