define([
	"dojo/_base/declare",
	"../../dojo/data/DataStoreBasedCreateTool",
], function (
	declare,
	DataStoreBasedCreateTool
) {

return declare(DataStoreBasedCreateTool, {
	//Defer to superclass
	
});

});