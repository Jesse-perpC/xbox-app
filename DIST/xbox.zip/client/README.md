Core Javascript Frameworks for all projects
===========================================

This repository is not indented to be used directly but rather as part of a consuming application via 'git submodule'. 
Such an example application can be found [here](https://github.com/mc007/xbox-app).
   
   Important: this is work in progress, don't use it until I say so ;-)
   

# Installation 

## Checkout 

1. git clone --recursive https://github.com/mc007/xjs or : 
2. git submodule update --init --recursive

## Update 

1. git submodule foreach git pull origin master

# Contribute

git commit -m "updated my submodule"
git push



## Dependencies

This project requires the following other projects to run:
 * dojo (is a sub module,forked)
 * dgrid (is a sub module,forked)
 * dojox (is a sub module,forked)
 * dijit (is a sub module,forked)
 * dcl  (is a sub module, https://github.com/uhop/dcl.git)
 * requirejs (is a sub module, https://github.com/jrburke/requirejs.git)
 * requirejs-domReady
 * requirejs-dplugins
 * requirejs-test

## Testing
 
 Is done via "intern". The selenium server must be started before : 
``` bash 
java -jar /usr/local/lib/node_modules/selenium-server-standalone-jar/jar -port 4444 -Dwebdriver.chrome.driver=chromedriver
```

 
## SDK 

[Guidelines] (GUIDELINES.md)

## Package Overview

**davinci** :  Old code of IBM's "Maqetta" project : to be removed soon! 

**xfile** : The file - manager widget, needs "xide".

**xide** : The IDEs foundation framework. This package serves the the infrastructure for all xjs based applications.

**xblox** : Library to render and execute  a visual programming language. This needs "xide", "xlog", "davinci", "system", "orion", "preview" and "dcl". This library can be used server and client side. Each "block" has an implementation to be rendered by "xide" (block fields,...). Please ignore this component for now!

**xstyle** Library to deal with CSS and Dom-Style manipulation.

**xlog** Library about logging, works server and client side. The library depends on "xide" and "dgrid" and contains custom views and widgets. 

**xwire** Library to bind data, events and widget properties all together. 

**orion** Old Editor library, parses CSS/Javascript and others. To be removed! 

**system** Old library, to be removed.

**preview** Old library, to be removed. 
 

## Build

``` bash
    cd src
    sh buildstandalone.sh    
```

This will create single layer file which contains all Dojo based in src/xfile/dojo/xbox.js!

## Build layers

For development speed, we did pre-compile some Dojo layers. By default 'dojox' and 'dijit' is pre-compiled. You can switch to normal in src/lib/xbox/run-release-debug.js !

``` bash
    cd src
    sh buildLayer.sh dojox
    sh buildLayer.sh dijit
```

To have 'pre-built' layers, you must have 3 files in your module folder: 

1. run.js
2. layer.profile.js
3. main.js

See in dojox, dijit or xfile for examples. 

## 'Other Components' 

Currently there are some alpha features in here which should not be used: xblox, davinci and orion.



